﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Player : Tank, IUserAction {//玩家坦克
	public delegate void destroy();
	public static event destroy destroyEvent;
    public GameObject player;

	void Start() {
		setHp(500f);//设置初始生命值为500
        player = GameDirector.getInstance().currentSceneController.mF.getPlayer();
    }
	void Update () {
        // 相机跟随玩家坦克
        Camera.main.transform.position = new Vector3(player.transform.position.x, 25, player.transform.position.z);
        if (getHp() <= 0 ) {//生命值<=0,表示玩家坦克被摧毁
			this.gameObject.SetActive(false);
			if (destroyEvent != null) {//执行委托事件
				destroyEvent();
			}
		}
	}

    public Vector3 getPlayerPos()
    {//返回玩家坦克的位置
        return player.transform.position;
    }

    public void moveForward()
    {
        player.GetComponent<Rigidbody>().velocity = player.transform.forward * 20;
    }
    public void moveBackWard()
    {
        player.GetComponent<Rigidbody>().velocity = player.transform.forward * -20;
    }
    public void turn(float offsetX)
    {//通过水平轴上的增量，改变玩家坦克的欧拉角，从而实现坦克转向
        float x = player.transform.localEulerAngles.y + offsetX * 5;
        float y = player.transform.localEulerAngles.x;
        player.transform.localEulerAngles = new Vector3(y, x, 0);
        Camera.main.transform.localEulerAngles = new Vector3(y + 90, x, 0);
    }

    public void shoot()
    {
        GameObject bullet = GameDirector.getInstance().currentSceneController.mF.getBullet(tankType.Player);//获取子弹，传入的参数表示发出子弹的坦克类型
        bullet.transform.position = new Vector3(player.transform.position.x, 1.5f, player.transform.position.z) +
            player.transform.forward * 1.5f;//设置子弹位置
        bullet.transform.forward = player.transform.forward;//设置子弹方向
        Rigidbody rb = bullet.GetComponent<Rigidbody>();
        rb.AddForce(bullet.transform.forward * 20, ForceMode.Impulse);//发射子弹
    }
}

